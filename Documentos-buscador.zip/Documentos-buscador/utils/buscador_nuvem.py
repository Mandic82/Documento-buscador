def buscar_onedrive(termo):
    # Placeholder para integração com Microsoft Graph API
    return []

def buscar_google_drive(termo):
    # Placeholder para integração com Google Drive API
    return []
